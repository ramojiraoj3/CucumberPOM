package com.qa.stepDefinitions;



import org.openqa.selenium.chrome.ChromeDriver;

import com.qa.pages.HomePage;
import com.qa.pages.addOns;
import com.qa.pages.bookSpicejet;
import com.qa.pages.passengerContactDetails;
import com.qa.pages.paymentDetails;
import com.qa.util.TestBase;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FlightBookingSteps extends TestBase
{
	HomePage hp;
	passengerContactDetails pcd;
	paymentDetails payment;
	
	@Given("^User opens browser$")
	public void user_opens_browser() throws Throwable {
		TestBase.initialization("browser");
	}

	@When("^user enters source and destination$")
	public void user_enters_source_and_destination() throws Throwable {
		hp=new HomePage();
		hp.source_Destination_Selection();
	  
	}

	@When("^user select the date$")
	public void user_select_the_date() throws Throwable {
		hp.dateSelection();
	}

	@Then("^user clicks on search button$")
	public void user_clicks_on_search_button() throws Throwable {
		hp.searchButton();
	    
	}
	@Then("^user click on continue button$")
	public void user_click_on_continue_button() throws Throwable {
	    bookSpicejet book=new bookSpicejet();
	    book.bookFlight();
	    
	}

	@When("^user fill the passenger contact details$")
	public void user_fill_the_passenger_contact_details() throws Throwable {
		pcd=new passengerContactDetails();
		pcd.contactDetails();
	    
	}

	@When("^user fill the passenger details$")
	public void user_fill_the_passenger_details() throws Throwable {
		pcd.passengerDetails();
    }

	@Then("^user click on next button$")
	public void user_click_on_next_button() throws Throwable {
		pcd.nextButton();
	    
	}

	@Then("^User click on continue pay button$")
	public void user_click_on_continue_pay_button() throws Throwable {
		addOns addon=new addOns();
		addon.addonPay();
	    
	}

	@When("^user fill all the bank details$")
	public void user_fill_all_the_bank_details() throws Throwable {
		payment=new paymentDetails();
		payment.cardDetails();
	    
	}

	@Then("^User click on hold button$")
	public void user_click_on_hold_button() throws Throwable {
		payment.holdButton();
	   
	}


}
