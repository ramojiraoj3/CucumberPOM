package com.qa.pages;

import java.util.logging.Logger;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.util.TestBase;

public class paymentDetails extends TestBase
{
	static Logger log= Logger.getLogger(paymentDetails.class.getName());
	@FindBy(xpath = "//input[@id='CONTROLGROUPPAYMENTBOTTOM_ControlGroupPaymentInputViewPaymentView_ExternalAccount_DN_ACCTNO']")
	WebElement cardNumber;
	@FindBy(xpath = "//select[@id='CONTROLGROUPPAYMENTBOTTOM_ControlGroupPaymentInputViewPaymentView_ExternalAccount_DN_EXPDAT_MONTH']")
	WebElement validityMonth;
	@FindBy(xpath = "//select[@id='CONTROLGROUPPAYMENTBOTTOM_ControlGroupPaymentInputViewPaymentView_ExternalAccount_DN_EXPDAT_YEAR']")
	WebElement validityYear;
	@FindBy(xpath = "//input[@id='CONTROLGROUPPAYMENTBOTTOM_ControlGroupPaymentInputViewPaymentView_ExternalAccount_DN_CC::VerificationCode']")
	WebElement cvvNumber;
	
	@FindBy(xpath = "//input[@id='btnHoldMyfare']") 
	WebElement holdFare;

	public paymentDetails()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void cardDetails() throws InterruptedException{
		Thread.sleep(5000);
		log.info("user give card number as:");
		cardNumber.sendKeys("478925631478");
		
		selectItem(validityMonth, 4);
		//Thread.sleep(3000);
		selectItem(validityYear, 5);
		//Thread.sleep(3000);
		cvvNumber.sendKeys("001");
	}
	public void holdButton() throws InterruptedException{
		log.info(driver.getTitle());
		Thread.sleep(5000);
		log.info("User select holdFare button to hold the ticket");
		holdFare.click();
		
	}
}
