package com.qa.pages;

import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.util.TestBase;

public class bookSpicejet extends TestBase
{
	static Logger log= Logger.getLogger(bookSpicejet.class.getName());
	@FindBy(xpath = "//span[@class='button-continue-text']") 
	WebElement continueButton;
	
	////Initializing the Page Objects:
	public bookSpicejet(){
		PageFactory.initElements(driver, this);
	}
	public void bookFlight() throws InterruptedException{
		//waitForElement(10, continueButton);
		Thread.sleep(5000);
		continueButton.click(); 
		log.info(driver.getCurrentUrl());
		//span[@class='button-continue-text']
		//driver.findElement(By.xpath("//span[@class='button-continue-text']")).click();
	}

}
