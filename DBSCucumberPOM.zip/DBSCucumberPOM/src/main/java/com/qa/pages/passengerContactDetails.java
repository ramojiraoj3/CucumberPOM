package com.qa.pages;

import java.util.logging.Logger;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.util.TestBase;

public class passengerContactDetails  extends TestBase
{
	static Logger log= Logger.getLogger(passengerContactDetails.class.getName());
	//Passenger contact details
	@FindBy(xpath = "//select[@id='CONTROLGROUPPASSENGER_ContactInputPassengerView_DropDownListTitle']") 
	WebElement gender;
	@FindBy(xpath = "//input[@id='CONTROLGROUPPASSENGER_ContactInputPassengerView_TextBoxFirstName']") 
	WebElement fname;
	@FindBy(xpath = "//input[@id='CONTROLGROUPPASSENGER_ContactInputPassengerView_TextBoxLastName']") 
	WebElement lname;
	@FindBy(xpath = "//input[@id='CONTROLGROUPPASSENGER_ContactInputPassengerView_TextBoxHomePhone']") 
	WebElement mobile;
	@FindBy(xpath = "//input[@id='CONTROLGROUPPASSENGER_ContactInputPassengerView_TextBoxEmailAddress']") 
	WebElement email;
	@FindBy(xpath = "//select[@id='CONTROLGROUPPASSENGER_ContactInputPassengerView_DropDownListCountry']") 
	WebElement country;
	@FindBy(xpath = "//select[@name='contact_cities_list_india']") 
	WebElement city;
	
	//Passenger details
	@FindBy(xpath = "//select[@id='CONTROLGROUPPASSENGER_PassengerInputViewPassengerView_DropDownListTitle_0']") 
	WebElement pgender;
	@FindBy(xpath = "//input[@id='CONTROLGROUPPASSENGER_PassengerInputViewPassengerView_TextBoxFirstName_0']") 
	WebElement passengerfname;
	@FindBy(xpath = "//input[@id='CONTROLGROUPPASSENGER_PassengerInputViewPassengerView_TextBoxLastName_0']") 
	WebElement passengerLname;
	@FindBy(xpath = "//input[@id='CONTROLGROUPPASSENGER_PassengerInputViewPassengerView_TextBoxEmailMobile_0']") 
	WebElement passengerMobileno;
	@FindBy(xpath = "//div[@id='continue-to-addons-page']//span[@class='button-continue-text'][contains(text(),'Continue')]") 
	WebElement next;

	//Initializing the Page Objects:
	public passengerContactDetails()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void contactDetails() throws InterruptedException{
		Thread.sleep(3000);
		log.info("user selects gender as male");
		selectItem(gender, 1);
		log.info("name as Ramoji");
		fname.sendKeys("Ramoji");
		lname.sendKeys("Jajam");
		mobile.sendKeys("9154828678");
		email.sendKeys("ramojirao@gmail.com");
		Thread.sleep(3000);
		log.info("user selects country as India");
		selectItem(country, 1);
		log.info("user selects city as Hyderabad");
		selectItem(city, 24);
		Thread.sleep(3000);
		
	}
	public void passengerDetails() throws InterruptedException{
		
		selectItem(pgender, 1);
		passengerfname.sendKeys("Ramoji");
		passengerLname.sendKeys("Jajam");
		passengerMobileno.sendKeys("9154828678");
		
		
	}
	public void nextButton() throws InterruptedException{
		Thread.sleep(5000);
		next.click();
		log.info(driver.getCurrentUrl());
		
	}
}
