package com.qa.util;

public class TestUtil 
{
	static int PAGE_LOAD_TIMEOUT = 20;
	static int IMPLICIT_WAIT = 30;

	
}
