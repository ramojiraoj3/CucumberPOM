package com.qa.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestBase 
{
	
	static Logger log= Logger.getLogger(TestBase.class.getName());
	public  static WebDriver driver;
	//public  Properties pro;
	
	
	static String path="./config.properties";
	 
	 public static String loadData(String value) throws IOException {
		 Properties pro=new Properties();
		 FileInputStream fis=new FileInputStream(path);
		 pro.load(fis);
		 String key = pro.getProperty(value);
		 return key;
	}
	/*public TestBase(){
		try{
			prop = new Properties();
			FileInputStream fis= new FileInputStream("E/softwares/DevWorkspace/DBSCucumberPOM/src/main/java/com/qa/config/config.properties");
			prop.load(fis);
		}
		catch(IOException e){
			e.getMessage();
		}
	
	}*/
	public static void initialization(String browser) throws IOException
	{
		//String browserName = prop.getProperty("browser");
		if(loadData(browser).equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver.exe");
			driver=new ChromeDriver();
		}
		else if(loadData(browser).equalsIgnoreCase("IE"))
		{
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"//drivers//IEDriverServer.exe");
			driver=new InternetExplorerDriver();
		}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		
		driver.get(loadData("url"));
		log.info(driver.getTitle());
	}
	
	public static void close()
	{
		driver.quit();
	}
	
	public void waitForElement(int timeInSeconds,WebElement element)
	{
		WebDriverWait wait=new WebDriverWait(driver, timeInSeconds);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	//By using below method you can call directly values using SELECT
	public void selectItem(WebElement element, int value)
	{
		Select s=new Select(element);
		s.selectByIndex(value);
	}
	

}
